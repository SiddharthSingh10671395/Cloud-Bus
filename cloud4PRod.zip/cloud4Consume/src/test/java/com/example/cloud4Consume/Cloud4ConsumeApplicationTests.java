package com.example.cloud4Consume;


import org.junit.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cloud4ConsumeApplicationTests {

	@Test
	void contextLoads() {
	}

}
