package com.example.cloud4PRod;

import org.junit.Test;

import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Cloud4PRodApplicationTests {

	@Test
	void contextLoads() {
	}

}
