package com.example.cloud4PRod;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class Cloud4PRodApplication {

	public static void main(String[] args) {
		SpringApplication.run(Cloud4PRodApplication.class, args);
	}

}
