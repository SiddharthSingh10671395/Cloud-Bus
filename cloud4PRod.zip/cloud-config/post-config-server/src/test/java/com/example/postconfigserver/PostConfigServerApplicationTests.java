package com.example.postconfigserver;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class PostConfigServerApplicationTests {

	@Test
	void contextLoads() {
	}

}
