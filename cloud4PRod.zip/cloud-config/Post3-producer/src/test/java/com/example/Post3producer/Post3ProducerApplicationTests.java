package com.example.Post3producer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Post3ProducerApplicationTests {

	@Test
	void contextLoads() {
	}

}
