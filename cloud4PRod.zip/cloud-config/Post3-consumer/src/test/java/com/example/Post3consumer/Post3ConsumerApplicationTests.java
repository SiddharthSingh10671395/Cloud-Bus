package com.example.Post3consumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Post3ConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
